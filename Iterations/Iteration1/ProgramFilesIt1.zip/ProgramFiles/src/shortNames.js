var addShortNames = function (theTournament) {
  let aSport = theTournament.findSport('Netball')

  aSport.addShortName('Australia', 'AUS')
  aSport.addShortName('Jamaica', 'JAM')
  aSport.addShortName('South Africa', 'RSA')
  aSport.addShortName('Northern Ireland', 'NIR')
  aSport.addShortName('Barbados', 'BAR')
  aSport.addShortName('Fiji', 'FIJ')

  aSport.addShortName('England', 'ENG')
  aSport.addShortName('New Zealand', 'NZL')
  aSport.addShortName('Uganda', 'UGA')
  aSport.addShortName('Malawi', 'MAW')
  aSport.addShortName('Scotland', 'SCO')
  aSport.addShortName('Wales', 'WAL')

  aSport = theTournament.findSport('Men\'s Rugby Sevens')
  aSport.addShortName('South Africa', 'RSA')
  aSport.addShortName('Scotland', 'SCO')
  aSport.addShortName('Papua New Guinea', 'PNG')
  aSport.addShortName('Malaysia', 'MAS')

  aSport.addShortName('England', 'ENG')
  aSport.addShortName('Australia', 'AUS')
  aSport.addShortName('Samoa', 'SAM')
  aSport.addShortName('Jamaica', 'JAM')

  aSport.addShortName('New Zealand', 'NZL')
  aSport.addShortName('Kenya', 'KEN')
  aSport.addShortName('Canada', 'CAN')
  aSport.addShortName('Zambia', 'ZAM')

  aSport.addShortName('Fiji', 'FIJ')
  aSport.addShortName('Wales', 'WAL')
  aSport.addShortName('Uganda', 'UGA')
  aSport.addShortName('Sri Lanka', 'SRI')

  aSport = theTournament.findSport('Women\'s Rugby Sevens')
  aSport.addShortName('New Zealand', 'NZL')
  aSport.addShortName('Canada', 'CAN')
  aSport.addShortName('Kenya', 'KEN')
  aSport.addShortName('South Africa', 'RSA')

  aSport.addShortName('Australia', 'AUS')
  aSport.addShortName('England', 'ENG')
  aSport.addShortName('Fiji', 'FIJ')
  aSport.addShortName('Wales', 'WAL')
}
